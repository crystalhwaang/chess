package chess;

/**
 * Represents a single square position on a chess board
 */
public class ChessPosition {

    private final int row;
    private final int col;

    public ChessPosition(int row, int col) {
        this.row = row;
        this.col = col;
    }

    /**
     * @return which row this position is in
     * 1 codes for the bottom row
     */
    public int getRow() {
        return row;
    }

    /**
     * @return which column this position is in
     * 1 codes for the left row
     */
    public int getColumn() {
        return col;
    }

    @Override
    public String toString() {
        return String.format("[%d,%d]", row, col);
    }

    @Override
    public boolean equals(Object object) {
        if (object == null || getClass() != object.getClass()) {
            return false;
        }

        ChessPosition that = (ChessPosition) object;
        return row == that.row && col == that.col;
    }

    @Override
//    public int hashCode() {
//        int result = super.hashCode();
//        result = 31 * result + row;
//        result = 31 * result + col;
//        return result;
//    }

    public int hashCode() {
        return java.util.Objects.hash(row, col);
    }
}
